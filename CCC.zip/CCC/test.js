const http = require('http');

const data = JSON.stringify({
    "num_cities": 3,
    "start_city": 0,
    "budget": 100,
    "max_time": 10,
    "city_names": ["New York", "London", "Paris"],
    "cost_matrix": [
        [0, 20, 30],
        [20, 0, 15],
        [30, 15, 0]
    ],
    "time_matrix": [
        [0, 2, 3],
        [2, 0, 1],
        [3, 1, 0]
    ]
});

const options = {
    hostname: 'localhost',
    port: 3000,
    path: '/api/optimize',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
    }
};

const req = http.request(options, res => {
    let responseData = '';
    res.on('data', chunk => {
        responseData += chunk;
    });
    res.on('end', () => {
        console.log('Status Code:', res.statusCode);
        console.log('Response:', responseData);
    });
});

req.on('error', error => {
    console.error('Error:', error);
});

req.write(data);
req.end();
