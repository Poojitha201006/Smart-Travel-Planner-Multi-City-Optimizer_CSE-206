const express = require('express');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/optimize', (req, res) => {
    const inputData = req.body;
    
    // We will compile the C++ executable to optimizer.exe on Windows
    const executablePath = path.join(__dirname, 'optimizer.exe');
    
    if (!fs.existsSync(executablePath)) {
        return res.status(500).json({ error: 'C++ executable not found. Please compile it first.' });
    }

    const cppProcess = spawn(executablePath);
    let outputData = '';
    let errorData = '';

    cppProcess.stdout.on('data', (data) => {
        outputData += data.toString();
    });

    cppProcess.stderr.on('data', (data) => {
        errorData += data.toString();
    });

    cppProcess.on('close', (code) => {
        if (code !== 0) {
            console.error(`C++ process exited with code ${code}`);
            console.error(errorData);
            return res.status(500).json({ error: 'Algorithm execution failed', details: errorData });
        }
        
        try {
            // The C++ process should output valid JSON
            const result = JSON.parse(outputData);
            res.json(result);
        } catch (e) {
            console.error('Failed to parse C++ output:', outputData);
            res.status(500).json({ error: 'Invalid output from algorithm', raw: outputData });
        }
    });

    // Send input data as JSON string to stdin of C++ process
    cppProcess.stdin.write(JSON.stringify(inputData));
    cppProcess.stdin.end();
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
