#include "dp.hpp"
#include <unordered_map>
#include <algorithm>

using namespace std;

struct DPResult {
    int max_cities_visited;
    int min_cost_used;
    int min_time_used;
    int next_city;
};

static int g_num_cities;
static const vector<vector<int>>* g_cost_matrix;
static const vector<vector<int>>* g_time_matrix;

static unordered_map<uint64_t, DPResult> memo;

static uint64_t encode_state(int mask, int city, int b, int t) {
    uint64_t state = 0;
    state |= (uint64_t)mask;
    state |= ((uint64_t)city << 16);
    state |= ((uint64_t)b << 24);
    state |= ((uint64_t)t << 40);
    return state;
}

static DPResult solve_dp(int mask, int city, int b, int t) {
    uint64_t state = encode_state(mask, city, b, t);
    if (memo.count(state)) {
        return memo[state];
    }

    // Base case: we are at 'city', having visited whatever is in 'mask'.
    // The current state itself counts as 0 ADDITIONAL cities.
    DPResult best = {0, 0, 0, -1};

    for (int nxt = 0; nxt < g_num_cities; nxt++) {
        if (!(mask & (1 << nxt))) {
            int cost = (*g_cost_matrix)[city][nxt];
            int travel_time = (*g_time_matrix)[city][nxt];
            
            if (b >= cost && t >= travel_time) {
                DPResult res = solve_dp(mask | (1 << nxt), nxt, b - cost, t - travel_time);
                
                int total_cities = res.max_cities_visited + 1;
                int total_cost_used = res.min_cost_used + cost;
                int total_time_used = res.min_time_used + travel_time;
                
                if (total_cities > best.max_cities_visited) {
                    best.max_cities_visited = total_cities;
                    best.min_cost_used = total_cost_used;
                    best.min_time_used = total_time_used;
                    best.next_city = nxt;
                } else if (total_cities == best.max_cities_visited && best.next_city != -1) {
                    // Tie breaker 1: minimize cost
                    if (total_cost_used < best.min_cost_used) {
                        best.min_cost_used = total_cost_used;
                        best.min_time_used = total_time_used;
                        best.next_city = nxt;
                    } 
                    // Tie breaker 2: minimize time
                    else if (total_cost_used == best.min_cost_used && total_time_used < best.min_time_used) {
                        best.min_time_used = total_time_used;
                        best.next_city = nxt;
                    }
                } else if (total_cities == best.max_cities_visited && best.next_city == -1) {
                    // If best was {0,0,0,-1} and total_cities is 0 (impossible since +1), or matching
                    best.min_cost_used = total_cost_used;
                    best.min_time_used = total_time_used;
                    best.next_city = nxt;
                }
            }
        }
    }

    memo[state] = best;
    return best;
}

json run_dp(int num_cities, int start_city, int budget, int max_time,
            const vector<string>& city_names,
            const vector<vector<int>>& cost_matrix,
            const vector<vector<int>>& time_matrix) {
    
    // Set globals for easy recursive access
    g_num_cities = num_cities;
    g_cost_matrix = &cost_matrix;
    g_time_matrix = &time_matrix;
    memo.clear();

    int initial_mask = (1 << start_city);
    DPResult res = solve_dp(initial_mask, start_city, budget, max_time);

    vector<string> route;
    route.push_back(city_names[start_city]);
    
    int curr_city = start_city;
    int b = budget;
    int t = max_time;
    int total_cost = 0;
    int total_time = 0;

    while (true) {
        uint64_t state = encode_state(initial_mask, curr_city, b, t);
        if (!memo.count(state)) break;
        int nxt = memo[state].next_city;
        if (nxt == -1) break;

        int cost = cost_matrix[curr_city][nxt];
        int travel_time = time_matrix[curr_city][nxt];

        route.push_back(city_names[nxt]);
        total_cost += cost;
        total_time += travel_time;

        b -= cost;
        t -= travel_time;
        initial_mask |= (1 << nxt);
        curr_city = nxt;
    }

    return {
        {"route", route},
        {"total_cost", total_cost},
        {"total_time", total_time},
        {"cities_visited", (int)route.size()}
    };
}
